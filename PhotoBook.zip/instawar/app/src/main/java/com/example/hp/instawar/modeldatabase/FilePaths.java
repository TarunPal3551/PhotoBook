package com.example.hp.instawar.modeldatabase;

/**
 * Created by hp on 20-Jan-18.
 */

public class FilePaths {
    public String FIREBASE_IMAGE_STORAGE="photos/users /";
}
