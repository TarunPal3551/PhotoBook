package com.example.hp.instawar;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.ArrayList;
import java.util.List;

public class UploadActivity extends AppCompatActivity {
    private Button selectbutton,uploadpost;
    private RecyclerView uploadlist;
    private static final int RESULT_LOAD_IMAGE = 1;
    private List<String> fileNamelist;
    private List<String> fileDonelist;
    private List<String> imageuri;
    private ImageView imageView;
    private UploadAdapter uploadAdapter;
    private StorageReference mStorageReference;
    private static String userID;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthlistener;
    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference mReference;
    Context mContext;
    Uri fileUri;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);
        selectbutton = (Button) findViewById(R.id.selectbutton);
        uploadlist = (RecyclerView) findViewById(R.id.recylerview);
        imageView = (ImageView) findViewById(R.id.imageview);
        mAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();
        mReference = firebaseDatabase.getReference();
        mContext = UploadActivity.this;

        mStorageReference = FirebaseStorage.getInstance().getReference();
        fileNamelist = new ArrayList<>();
        fileDonelist = new ArrayList<>();
        imageuri = new ArrayList<>();
        uploadAdapter = new UploadAdapter(mContext, fileNamelist, fileDonelist, imageuri);
        uploadlist.setLayoutManager(new LinearLayoutManager(this));
        uploadlist.setHasFixedSize(true);
        uploadlist.setAdapter(uploadAdapter);

        selectbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "select images"), RESULT_LOAD_IMAGE);
            }
        });


    }

    @SuppressLint("NewApi")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK) {

            if (data.getClipData() != null) {

                int totalitemselected = data.getClipData().getItemCount();
                for (int i = 0; i < totalitemselected; i++) {
                     fileUri = data.getClipData().getItemAt(i).getUri();
                    final String filename = getFileName(fileUri);

                    fileNamelist.add(filename);
                    fileDonelist.add("uploading");
                    uploadAdapter.notifyDataSetChanged();
                    userID=mAuth.getCurrentUser().getUid();
                    final StorageReference filerefrence = mStorageReference.child("uploadedalbums").child(userID).child(filename);
                    final int finalI = i;
                    final int finalI1 = i;
                    filerefrence.putFile(fileUri)
                            .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                @Override
                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                    Toast.makeText(mContext," file uploaded"+ finalI1,Toast.LENGTH_SHORT).show();
                                    fileDonelist.remove(finalI);
                                    fileDonelist.add(finalI, "Done");
                                    uploadAdapter.notifyDataSetChanged();


                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {

                                }
                            });

                }

                Toast.makeText(UploadActivity.this, "select multiple image", Toast.LENGTH_SHORT).show();
            } else if (data.getData() != null) {

                Toast.makeText(UploadActivity.this, "select single file", Toast.LENGTH_SHORT).show();
            }


        }


    }

    private String getFileExtension(Uri uri) {
        ContentResolver contentResolver = getContentResolver();
        MimeTypeMap map = MimeTypeMap.getSingleton();
        return map.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    public String getFileName(Uri uri) {

        String result = null;
        if (uri.getScheme().equals("content")) {

            Cursor cursor = getContentResolver().query(uri, null, null, null, null);
            try {
                if (cursor != null && cursor.moveToFirst()) {

                    result = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));

                }
            } finally {
                cursor.close();
            }


        }
        if (result == null) {
            result = uri.getPath();
            int cut = result.lastIndexOf('/');
            if (cut != -1) {

                result = result.substring(cut + 1);

            }


        }
        return result;


    }
}
